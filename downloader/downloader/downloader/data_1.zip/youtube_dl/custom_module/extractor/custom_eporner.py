# coding: utf-8
from __future__ import unicode_literals

import re

from youtube_dl.extractor.common import InfoExtractor
from youtube_dl.utils import (
    encode_base_n,
    ExtractorError,
    int_or_none,
    merge_dicts,
    parse_duration,
    str_to_int,
    url_or_none,
)


class CustomEpornerIE(InfoExtractor):
    _VALID_URL = r'https?://(?:www\.)?eporner\.com/(?:hd-porn|embed)/(?P<id>\w+)(?:/(?P<display_id>[\w-]+))?'

    def _real_extract(self, url):
        mobj = re.match(self._VALID_URL, url)
        video_id = mobj.group('id')
        display_id = mobj.group('display_id') or video_id

        webpage, urlh = self._download_webpage_handle(url, display_id)

        video_id = self._match_id(urlh.geturl())

        hash = self._search_regex(
            r'hash\s*=\s*["\']([\da-f]{32})', webpage, 'hash')

        title = self._og_search_title(webpage,
                                      default=None) or self._html_search_regex(
            r'<title>(.+?) - EPORNER', webpage, 'title')

        file_infos = re.findall(r'Download MP4 \((.*?)\)', webpage, re.S)
        file_infos = dict(
            list(tuple(map(lambda fs: fs.split(','), file_infos))))

        # Reverse engineered from vjs.js
        def calc_hash(s):
            return ''.join((encode_base_n(int(s[lb:lb + 8], 16), 36) for lb in
                            range(0, 32, 8)))

        video = self._download_json(
            'http://www.eporner.com/xhr/video/%s' % video_id,
            display_id, note='Downloading video JSON',
            query={
                'hash': calc_hash(hash),
                'device': 'generic',
                'domain': 'www.eporner.com',
                'fallback': 'false',
            })

        if video.get('available') is False:
            raise ExtractorError(
                '%s said: %s' % (self.IE_NAME, video['message']), expected=True)

        sources = video['sources']

        formats = []
        for kind, formats_dict in sources.items():
            if not isinstance(formats_dict, dict):
                continue
            for format_id, format_dict in formats_dict.items():
                if not isinstance(format_dict, dict):
                    continue
                src = url_or_none(format_dict.get('src'))
                if not src or not src.startswith('http'):
                    continue
                if kind == 'hls':
                    formats.extend(self._extract_m3u8_formats(
                        src, display_id, 'mp4', entry_protocol='m3u8_native',
                        m3u8_id=kind, fatal=False))
                else:
                    height = int_or_none(self._search_regex(
                        r'(\d+)[pP]', format_id, 'height', default=None))
                    fps = int_or_none(self._search_regex(
                        r'(\d+)fps', format_id, 'fps', default=None))
                    filesize = file_infos.get('{}p'.format(height), '')
                    if filesize:
                        if 'MB' in filesize:
                            filesize = filesize.replace('MB', '').strip()
                            filesize = round(float(filesize)) * 1024 * 1024
                        elif 'GB' in filesize:
                            filesize = filesize.replace('GB', '').strip()
                            filesize = round(
                                float(filesize)) * 1024 * 1024 * 1024

                    formats.append({
                        'url': src,
                        'format_id': format_id,
                        'height': height,
                        'fps': fps,
                        'filesize': filesize
                    })
        self._sort_formats(formats)

        json_ld = self._search_json_ld(webpage, display_id, default={})

        duration = parse_duration(self._html_search_meta(
            'duration', webpage, default=None))
        view_count = str_to_int(self._html_search_regex(
            r'<div id="cinemaviews1" title="Views">(.*?)</div>',
            webpage, 'view count'))

        publishedAt = self._html_search_regex(
            r'''"uploadDate": "(.*?)",''',
            webpage,
            'publishedAt'
        ).split('T')[0]
        description = self._html_search_meta(
            'description',
            webpage,
            'description'
        )

        return merge_dicts(json_ld, {
            'id': video_id,
            'display_id': display_id,
            'title': title,
            'description': description,
            'duration': duration,
            'view_count': view_count,
            'publishedAt': publishedAt,
            'formats': formats,
            'age_limit': 18,
            'player': '<iframe width="100%" height="100%" frameborder="0" allowfullscreen src="https://www.eporner.com/embed/{}"></iframe>'.format(video_id)
        })
